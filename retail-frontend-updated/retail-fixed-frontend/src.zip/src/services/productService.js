// src/services/productService.js
// Mirrors GET/POST/PUT/DELETE /products endpoints from the SRS.
import { products } from '../data/mockData';

const delay = (ms = 300) => new Promise((res) => setTimeout(res, ms));
let nextId = products.length + 1;

export async function getProducts({ search = '', category = '' } = {}) {
  await delay();
  const filtered = products.filter(
    (p) =>
      p.productName.toLowerCase().includes(search.toLowerCase()) &&
      (category ? p.category === category : true)
  );
  return { data: filtered, total: filtered.length };
}

export async function getProduct(id) {
  await delay();
  const found = products.find((p) => p.productId === Number(id));
  if (!found) {
    const err = new Error('Product not found');
    err.status = 404;
    throw err;
  }
  return found;
}

export async function createProduct(payload) {
  await delay();
  const newProduct = { productId: nextId++, ...payload };
  products.push(newProduct);
  return newProduct;
}

export async function updateProduct(id, payload) {
  await delay();
  const idx = products.findIndex((p) => p.productId === Number(id));
  if (idx === -1) {
    const err = new Error('Product not found');
    err.status = 404;
    throw err;
  }
  products[idx] = { ...products[idx], ...payload };
  return products[idx];
}

export async function deleteProduct(id) {
  await delay();
  const idx = products.findIndex((p) => p.productId === Number(id));
  if (idx === -1) {
    const err = new Error('Product not found');
    err.status = 404;
    throw err;
  }
  products.splice(idx, 1);
  return { message: 'Product deleted successfully' };
}

export const categories = ['Groceries', 'Electronics', 'Apparel', 'Personal Care'];
