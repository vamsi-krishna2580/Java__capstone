// src/services/inventoryService.js
// Mirrors /inventory, /inventory/low-stock, /inventory/history,
// /inventory/recommendations from the SRS.
import { inventory, inventoryHistory, predictions } from '../data/mockData';

const delay = (ms = 300) => new Promise((res) => setTimeout(res, ms));

export async function getInventory() {
  await delay();
  return { data: inventory, total: inventory.length };
}

export async function updateInventoryItem(id, payload) {
  await delay();
  const idx = inventory.findIndex((i) => i.inventoryId === Number(id));
  if (idx === -1) {
    const err = new Error('Inventory record not found');
    err.status = 404;
    throw err;
  }
  inventory[idx] = { ...inventory[idx], ...payload, lastUpdated: new Date().toISOString() };
  return inventory[idx];
}

export async function getLowStock() {
  await delay();
  const low = inventory
    .filter((i) => i.availableStock <= i.threshold)
    .sort((a, b) => a.availableStock / a.threshold - b.availableStock / b.threshold);
  return { data: low };
}

export async function getInventoryHistory() {
  await delay();
  return { data: inventoryHistory };
}

export async function getRecommendations() {
  await delay();
  return {
    data: predictions
      .filter((p) => p.reorderQuantity > 0)
      .map((p) => ({
        productId: p.productId,
        productName: p.productName,
        recommendedStock: p.recommendedStock,
        reorderQuantity: p.reorderQuantity,
      })),
  };
}
