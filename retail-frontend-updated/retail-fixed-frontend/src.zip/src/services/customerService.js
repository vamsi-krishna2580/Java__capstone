// src/services/customerService.js
// Mirrors GET/POST/PUT/DELETE /customers endpoints from the SRS.
import { customers } from '../data/mockData';

const delay = (ms = 300) => new Promise((res) => setTimeout(res, ms));
let nextId = customers.length + 1;

export async function getCustomers({ search = '' } = {}) {
  await delay();
  const filtered = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase())
  );
  return { data: filtered, total: filtered.length };
}

export async function getCustomer(id) {
  await delay();
  const found = customers.find((c) => c.customerId === Number(id));
  if (!found) {
    const err = new Error('Customer not found');
    err.status = 404;
    throw err;
  }
  return found;
}

export async function createCustomer(payload) {
  await delay();
  const newCustomer = {
    customerId: nextId++,
    registrationDate: new Date().toISOString().slice(0, 10),
    ...payload,
  };
  customers.push(newCustomer);
  return newCustomer;
}

export async function updateCustomer(id, payload) {
  await delay();
  const idx = customers.findIndex((c) => c.customerId === Number(id));
  if (idx === -1) {
    const err = new Error('Customer not found');
    err.status = 404;
    throw err;
  }
  customers[idx] = { ...customers[idx], ...payload };
  return customers[idx];
}

export async function deleteCustomer(id) {
  await delay();
  const idx = customers.findIndex((c) => c.customerId === Number(id));
  if (idx === -1) {
    const err = new Error('Customer not found');
    err.status = 404;
    throw err;
  }
  customers.splice(idx, 1);
  return { message: 'Customer deleted successfully' };
}
