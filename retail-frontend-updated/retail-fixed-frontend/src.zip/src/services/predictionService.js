// src/services/predictionService.js
// Mirrors /prediction/demand, /prediction/reorder, /prediction/forecast from the SRS.
import { predictions } from '../data/mockData';

const delay = (ms = 300) => new Promise((res) => setTimeout(res, ms));

export async function getDemandPredictions() {
  await delay();
  return { data: predictions };
}

export async function getReorderRecommendations() {
  await delay();
  return {
    data: predictions
      .filter((p) => p.reorderQuantity > 0)
      .map(({ productId, productName, currentStock, recommendedStock, reorderQuantity }) => ({
        productId,
        productName,
        currentStock,
        recommendedStock,
        reorderQuantity,
      })),
  };
}

export async function getForecast(productId, months = 6) {
  await delay();
  const base = predictions.find((p) => p.productId === Number(productId));
  if (!base) {
    const err = new Error('Product not found');
    err.status = 404;
    throw err;
  }
  const forecast = Array.from({ length: months }, (_, i) => {
    const monthDate = new Date(2026, 5 + i + 1, 1);
    const seasonalFactor = 1 + Math.sin(i / 2) * 0.1;
    return {
      month: monthDate.toISOString().slice(0, 7),
      predictedDemand: Math.round(base.predictedDemand * seasonalFactor),
    };
  });
  return { productId: base.productId, productName: base.productName, forecast };
}
