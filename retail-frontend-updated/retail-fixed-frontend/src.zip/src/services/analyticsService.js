// src/services/analyticsService.js
// Mirrors /analytics/* endpoints from the SRS.
import {
  dailySalesHourly,
  monthlySales,
  revenueTrend,
  topProducts,
  customerTrends,
  salesByCategory,
} from '../data/mockData';

const delay = (ms = 300) => new Promise((res) => setTimeout(res, ms));

export async function getDailySales(date) {
  await delay();
  const total = dailySalesHourly.reduce((sum, h) => sum + h.sales, 0);
  return { date: date || new Date().toISOString().slice(0, 10), totalSales: total, transactionCount: 18, hourlyBreakdown: dailySalesHourly };
}

export async function getMonthlySales() {
  await delay();
  const current = monthlySales[monthlySales.length - 1];
  return { month: current.month, totalSales: current.sales, dailyBreakdown: monthlySales };
}

export async function getRevenue() {
  await delay();
  const totalRevenue = monthlySales[monthlySales.length - 1].sales;
  const totalCost = totalRevenue * 0.62;
  return {
    totalRevenue,
    totalCost,
    profitMargin: Number((((totalRevenue - totalCost) / totalRevenue) * 100).toFixed(1)),
    trend: revenueTrend,
  };
}

export async function getTopProducts(limit = 5) {
  await delay();
  return { data: topProducts.slice(0, limit) };
}

export async function getCustomerTrends() {
  await delay();
  return customerTrends;
}

export async function getSalesByCategory() {
  await delay();
  return { data: salesByCategory };
}
