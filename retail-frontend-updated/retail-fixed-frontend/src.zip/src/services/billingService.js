// src/services/billingService.js
// Mirrors POST /billing/create, GET /billing/{id}, GET /billing/history,
// POST /billing/payment from the SRS.
import { bills, products, inventory, customers } from '../data/mockData';

const delay = (ms = 300) => new Promise((res) => setTimeout(res, ms));
let nextBillId = Math.max(...bills.map((b) => b.billId)) + 1;

export async function createBill({ customerId, items, tax = 0, discount = 0 }) {
  await delay();
  if (!items || items.length === 0) {
    const err = new Error('Bill must contain at least one item');
    err.status = 400;
    throw err;
  }

  const billItems = items.map(({ productId, quantity }) => {
    const product = products.find((p) => p.productId === Number(productId));
    if (!product) {
      const err = new Error(`Product ${productId} not found`);
      err.status = 404;
      throw err;
    }
    const invItem = inventory.find((i) => i.productId === Number(productId));
    if (invItem.availableStock < quantity) {
      const err = new Error(`Insufficient stock for ${product.productName}`);
      err.status = 409;
      throw err;
    }
    return {
      productId: product.productId,
      productName: product.productName,
      quantity,
      unitPrice: product.price,
      subtotal: product.price * quantity,
    };
  });

  // Deduct stock (simulating thread-safe stock update)
  billItems.forEach(({ productId, quantity }) => {
    const invItem = inventory.find((i) => i.productId === productId);
    invItem.availableStock -= quantity;
    const product = products.find((p) => p.productId === productId);
    product.quantity -= quantity;
  });

  const subtotal = billItems.reduce((sum, i) => sum + i.subtotal, 0);
  const totalAmount = subtotal + tax - discount;
  const customer = customers.find((c) => c.customerId === Number(customerId));

  const bill = {
    billId: nextBillId++,
    customerId: Number(customerId),
    customerName: customer?.name || 'Walk-in Customer',
    billDate: new Date().toISOString(),
    items: billItems,
    tax,
    discount,
    totalAmount,
    paymentStatus: 'PENDING',
  };
  bills.unshift(bill);
  return bill;
}

export async function getBill(id) {
  await delay();
  const found = bills.find((b) => b.billId === Number(id));
  if (!found) {
    const err = new Error('Bill not found');
    err.status = 404;
    throw err;
  }
  return found;
}

export async function getBillingHistory() {
  await delay();
  return { data: bills, total: bills.length };
}

export async function recordPayment({ billId, paymentMethod, amount }) {
  await delay();
  const bill = bills.find((b) => b.billId === Number(billId));
  if (!bill) {
    const err = new Error('Bill not found');
    err.status = 404;
    throw err;
  }
  bill.paymentStatus = 'PAID';
  return {
    transactionId: Date.now(),
    billId: bill.billId,
    paymentMethod,
    amount,
    status: 'SUCCESS',
    transactionDate: new Date().toISOString(),
  };
}
